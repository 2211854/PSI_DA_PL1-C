﻿namespace RestGest
{
    partial class FormIndividualRestaurante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormIndividualRestaurante));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPagePainelDeControlo = new System.Windows.Forms.TabPage();
            this.buttonPedidos = new System.Windows.Forms.Button();
            this.comboBoxRestaurantes = new System.Windows.Forms.ComboBox();
            this.labelTotalFaturado = new System.Windows.Forms.Label();
            this.labelNumeroPedidos = new System.Windows.Forms.Label();
            this.labelNumeroTrabalhadores = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPageTrabalhadores = new System.Windows.Forms.TabPage();
            this.tabControlRestaurantes = new System.Windows.Forms.TabControl();
            this.tabPageInserirRestaurantes = new System.Windows.Forms.TabPage();
            this.textBoxTelemovelTrabalhador = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBoxEstadoTrabalhador = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxCidadeTrabalhador = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxPaisTrabalhador = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonAdicionarTrabalhador = new System.Windows.Forms.Button();
            this.textBoxRuaTrabalhador = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxCodPostalTrabalhador = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxSalarioTrabalhador = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBoxPosicaoTrabalhador = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxNomeTrabalhador = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPageEditarRestaurantes = new System.Windows.Forms.TabPage();
            this.textBoxTelemovelTrabalhadorAlterar = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBoxEstadoTrabalhadorAlterar = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxCidadeTrabalhadorAlterar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPaisTrabalhadorAlterar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxRuaTrabalhadorAlterar = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxCodPostalTrabalhadorAlterar = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxSalarioTrabalhadorAlterar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxPosicaoTrabalhadorAlterar = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxNomeTrabalhadorAlterar = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonEditarTrabalhador = new System.Windows.Forms.Button();
            this.groupBoxListaTrabalhadores = new System.Windows.Forms.GroupBox();
            this.labelTotalSalarios = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.listBoxTrabalhadores = new System.Windows.Forms.ListBox();
            this.tabPageMenus = new System.Windows.Forms.TabPage();
            this.buttonRemoverMenu = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listBoxMenuRestaurante = new System.Windows.Forms.ListBox();
            this.buttonAdicionarMenu = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBoxMenus = new System.Windows.Forms.ListBox();
            this.tabControl1.SuspendLayout();
            this.tabPagePainelDeControlo.SuspendLayout();
            this.tabPageTrabalhadores.SuspendLayout();
            this.tabControlRestaurantes.SuspendLayout();
            this.tabPageInserirRestaurantes.SuspendLayout();
            this.tabPageEditarRestaurantes.SuspendLayout();
            this.groupBoxListaTrabalhadores.SuspendLayout();
            this.tabPageMenus.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPagePainelDeControlo);
            this.tabControl1.Controls.Add(this.tabPageTrabalhadores);
            this.tabControl1.Controls.Add(this.tabPageMenus);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(727, 456);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPagePainelDeControlo
            // 
            this.tabPagePainelDeControlo.Controls.Add(this.buttonPedidos);
            this.tabPagePainelDeControlo.Controls.Add(this.comboBoxRestaurantes);
            this.tabPagePainelDeControlo.Controls.Add(this.labelTotalFaturado);
            this.tabPagePainelDeControlo.Controls.Add(this.labelNumeroPedidos);
            this.tabPagePainelDeControlo.Controls.Add(this.labelNumeroTrabalhadores);
            this.tabPagePainelDeControlo.Controls.Add(this.label1);
            this.tabPagePainelDeControlo.Location = new System.Drawing.Point(4, 22);
            this.tabPagePainelDeControlo.Name = "tabPagePainelDeControlo";
            this.tabPagePainelDeControlo.Size = new System.Drawing.Size(719, 430);
            this.tabPagePainelDeControlo.TabIndex = 2;
            this.tabPagePainelDeControlo.Text = "Painel de Controlo";
            this.tabPagePainelDeControlo.UseVisualStyleBackColor = true;
            // 
            // buttonPedidos
            // 
            this.buttonPedidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPedidos.Image = global::RestGest.Properties.Resources.receipt_solid;
            this.buttonPedidos.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonPedidos.Location = new System.Drawing.Point(429, 78);
            this.buttonPedidos.Name = "buttonPedidos";
            this.buttonPedidos.Size = new System.Drawing.Size(143, 165);
            this.buttonPedidos.TabIndex = 29;
            this.buttonPedidos.Text = "Pedidos";
            this.buttonPedidos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonPedidos.UseVisualStyleBackColor = true;
            this.buttonPedidos.Click += new System.EventHandler(this.buttonPedidos_Click);
            // 
            // comboBoxRestaurantes
            // 
            this.comboBoxRestaurantes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.comboBoxRestaurantes.FormattingEnabled = true;
            this.comboBoxRestaurantes.Location = new System.Drawing.Point(335, 19);
            this.comboBoxRestaurantes.Name = "comboBoxRestaurantes";
            this.comboBoxRestaurantes.Size = new System.Drawing.Size(237, 33);
            this.comboBoxRestaurantes.TabIndex = 4;
            this.comboBoxRestaurantes.SelectedIndexChanged += new System.EventHandler(this.comboBoxRestaurantes_SelectedIndexChanged);
            // 
            // labelTotalFaturado
            // 
            this.labelTotalFaturado.AutoSize = true;
            this.labelTotalFaturado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalFaturado.Location = new System.Drawing.Point(31, 194);
            this.labelTotalFaturado.Name = "labelTotalFaturado";
            this.labelTotalFaturado.Size = new System.Drawing.Size(318, 25);
            this.labelTotalFaturado.TabIndex = 3;
            this.labelTotalFaturado.Text = "Total Faturado: {Total Faturado}";
            // 
            // labelNumeroPedidos
            // 
            this.labelNumeroPedidos.AutoSize = true;
            this.labelNumeroPedidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumeroPedidos.Location = new System.Drawing.Point(31, 144);
            this.labelNumeroPedidos.Name = "labelNumeroPedidos";
            this.labelNumeroPedidos.Size = new System.Drawing.Size(252, 25);
            this.labelNumeroPedidos.TabIndex = 2;
            this.labelNumeroPedidos.Text = "Nº Pedidos: {Nº Pedidos}";
            // 
            // labelNumeroTrabalhadores
            // 
            this.labelNumeroTrabalhadores.AutoSize = true;
            this.labelNumeroTrabalhadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumeroTrabalhadores.Location = new System.Drawing.Point(31, 93);
            this.labelNumeroTrabalhadores.Name = "labelNumeroTrabalhadores";
            this.labelNumeroTrabalhadores.Size = new System.Drawing.Size(290, 25);
            this.labelNumeroTrabalhadores.TabIndex = 1;
            this.labelNumeroTrabalhadores.Text = "Nº Trabalhadores: {Nº Trabs}";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(155, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "RESTAURANTE:";
            // 
            // tabPageTrabalhadores
            // 
            this.tabPageTrabalhadores.Controls.Add(this.tabControlRestaurantes);
            this.tabPageTrabalhadores.Controls.Add(this.groupBoxListaTrabalhadores);
            this.tabPageTrabalhadores.Location = new System.Drawing.Point(4, 22);
            this.tabPageTrabalhadores.Name = "tabPageTrabalhadores";
            this.tabPageTrabalhadores.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTrabalhadores.Size = new System.Drawing.Size(719, 430);
            this.tabPageTrabalhadores.TabIndex = 0;
            this.tabPageTrabalhadores.Text = "Trabalhadores";
            this.tabPageTrabalhadores.UseVisualStyleBackColor = true;
            // 
            // tabControlRestaurantes
            // 
            this.tabControlRestaurantes.Controls.Add(this.tabPageInserirRestaurantes);
            this.tabControlRestaurantes.Controls.Add(this.tabPageEditarRestaurantes);
            this.tabControlRestaurantes.Location = new System.Drawing.Point(376, 6);
            this.tabControlRestaurantes.Name = "tabControlRestaurantes";
            this.tabControlRestaurantes.SelectedIndex = 0;
            this.tabControlRestaurantes.Size = new System.Drawing.Size(331, 417);
            this.tabControlRestaurantes.TabIndex = 20;
            // 
            // tabPageInserirRestaurantes
            // 
            this.tabPageInserirRestaurantes.Controls.Add(this.textBoxTelemovelTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label14);
            this.tabPageInserirRestaurantes.Controls.Add(this.comboBoxEstadoTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label11);
            this.tabPageInserirRestaurantes.Controls.Add(this.textBoxCidadeTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label3);
            this.tabPageInserirRestaurantes.Controls.Add(this.textBoxPaisTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label8);
            this.tabPageInserirRestaurantes.Controls.Add(this.buttonAdicionarTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.textBoxRuaTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label18);
            this.tabPageInserirRestaurantes.Controls.Add(this.textBoxCodPostalTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label19);
            this.tabPageInserirRestaurantes.Controls.Add(this.textBoxSalarioTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label20);
            this.tabPageInserirRestaurantes.Controls.Add(this.textBoxPosicaoTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label21);
            this.tabPageInserirRestaurantes.Controls.Add(this.textBoxNomeTrabalhador);
            this.tabPageInserirRestaurantes.Controls.Add(this.label22);
            this.tabPageInserirRestaurantes.Location = new System.Drawing.Point(4, 22);
            this.tabPageInserirRestaurantes.Name = "tabPageInserirRestaurantes";
            this.tabPageInserirRestaurantes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageInserirRestaurantes.Size = new System.Drawing.Size(323, 391);
            this.tabPageInserirRestaurantes.TabIndex = 0;
            this.tabPageInserirRestaurantes.Text = "Adicionar";
            this.tabPageInserirRestaurantes.UseVisualStyleBackColor = true;
            // 
            // textBoxTelemovelTrabalhador
            // 
            this.textBoxTelemovelTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxTelemovelTrabalhador.Location = new System.Drawing.Point(123, 60);
            this.textBoxTelemovelTrabalhador.MaxLength = 9;
            this.textBoxTelemovelTrabalhador.Name = "textBoxTelemovelTrabalhador";
            this.textBoxTelemovelTrabalhador.Size = new System.Drawing.Size(151, 26);
            this.textBoxTelemovelTrabalhador.TabIndex = 35;
            this.textBoxTelemovelTrabalhador.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTelemovelTrabalhador_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label14.Location = new System.Drawing.Point(32, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 20);
            this.label14.TabIndex = 34;
            this.label14.Text = "Telemovel:";
            // 
            // comboBoxEstadoTrabalhador
            // 
            this.comboBoxEstadoTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxEstadoTrabalhador.FormattingEnabled = true;
            this.comboBoxEstadoTrabalhador.Items.AddRange(new object[] {
            "Ativado",
            "Desativado"});
            this.comboBoxEstadoTrabalhador.Location = new System.Drawing.Point(122, 299);
            this.comboBoxEstadoTrabalhador.Name = "comboBoxEstadoTrabalhador";
            this.comboBoxEstadoTrabalhador.Size = new System.Drawing.Size(152, 28);
            this.comboBoxEstadoTrabalhador.TabIndex = 33;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(52, 302);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 20);
            this.label11.TabIndex = 32;
            this.label11.Text = "Estado:";
            // 
            // textBoxCidadeTrabalhador
            // 
            this.textBoxCidadeTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxCidadeTrabalhador.Location = new System.Drawing.Point(123, 235);
            this.textBoxCidadeTrabalhador.Name = "textBoxCidadeTrabalhador";
            this.textBoxCidadeTrabalhador.Size = new System.Drawing.Size(151, 26);
            this.textBoxCidadeTrabalhador.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(53, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Cidade:";
            // 
            // textBoxPaisTrabalhador
            // 
            this.textBoxPaisTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxPaisTrabalhador.Location = new System.Drawing.Point(123, 267);
            this.textBoxPaisTrabalhador.Name = "textBoxPaisTrabalhador";
            this.textBoxPaisTrabalhador.Size = new System.Drawing.Size(151, 26);
            this.textBoxPaisTrabalhador.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.Location = new System.Drawing.Point(73, 270);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 20);
            this.label8.TabIndex = 28;
            this.label8.Text = "Pais:";
            // 
            // buttonAdicionarTrabalhador
            // 
            this.buttonAdicionarTrabalhador.Location = new System.Drawing.Point(123, 354);
            this.buttonAdicionarTrabalhador.Name = "buttonAdicionarTrabalhador";
            this.buttonAdicionarTrabalhador.Size = new System.Drawing.Size(75, 23);
            this.buttonAdicionarTrabalhador.TabIndex = 27;
            this.buttonAdicionarTrabalhador.Text = "Adicionar";
            this.buttonAdicionarTrabalhador.UseVisualStyleBackColor = true;
            this.buttonAdicionarTrabalhador.Click += new System.EventHandler(this.buttonAdicionarTrabalhador_Click);
            // 
            // textBoxRuaTrabalhador
            // 
            this.textBoxRuaTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxRuaTrabalhador.Location = new System.Drawing.Point(123, 166);
            this.textBoxRuaTrabalhador.Name = "textBoxRuaTrabalhador";
            this.textBoxRuaTrabalhador.Size = new System.Drawing.Size(151, 26);
            this.textBoxRuaTrabalhador.TabIndex = 25;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label18.Location = new System.Drawing.Point(73, 169);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 20);
            this.label18.TabIndex = 24;
            this.label18.Text = "Rua:";
            // 
            // textBoxCodPostalTrabalhador
            // 
            this.textBoxCodPostalTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxCodPostalTrabalhador.Location = new System.Drawing.Point(123, 203);
            this.textBoxCodPostalTrabalhador.MaxLength = 8;
            this.textBoxCodPostalTrabalhador.Name = "textBoxCodPostalTrabalhador";
            this.textBoxCodPostalTrabalhador.Size = new System.Drawing.Size(151, 26);
            this.textBoxCodPostalTrabalhador.TabIndex = 23;
            this.textBoxCodPostalTrabalhador.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCodPostalTrabalhador_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label19.Location = new System.Drawing.Point(22, 206);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 20);
            this.label19.TabIndex = 22;
            this.label19.Text = "Cod. Postal:";
            // 
            // textBoxSalarioTrabalhador
            // 
            this.textBoxSalarioTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxSalarioTrabalhador.Location = new System.Drawing.Point(123, 129);
            this.textBoxSalarioTrabalhador.Name = "textBoxSalarioTrabalhador";
            this.textBoxSalarioTrabalhador.Size = new System.Drawing.Size(151, 26);
            this.textBoxSalarioTrabalhador.TabIndex = 21;
            this.textBoxSalarioTrabalhador.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSalarioTrabalhador_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label20.Location = new System.Drawing.Point(54, 132);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(62, 20);
            this.label20.TabIndex = 20;
            this.label20.Text = "Salário:";
            // 
            // textBoxPosicaoTrabalhador
            // 
            this.textBoxPosicaoTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxPosicaoTrabalhador.Location = new System.Drawing.Point(123, 92);
            this.textBoxPosicaoTrabalhador.Name = "textBoxPosicaoTrabalhador";
            this.textBoxPosicaoTrabalhador.Size = new System.Drawing.Size(151, 26);
            this.textBoxPosicaoTrabalhador.TabIndex = 19;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label21.Location = new System.Drawing.Point(47, 95);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 20);
            this.label21.TabIndex = 18;
            this.label21.Text = "Posição:";
            // 
            // textBoxNomeTrabalhador
            // 
            this.textBoxNomeTrabalhador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxNomeTrabalhador.Location = new System.Drawing.Point(123, 28);
            this.textBoxNomeTrabalhador.Name = "textBoxNomeTrabalhador";
            this.textBoxNomeTrabalhador.Size = new System.Drawing.Size(151, 26);
            this.textBoxNomeTrabalhador.TabIndex = 17;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label22.Location = new System.Drawing.Point(61, 31);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 20);
            this.label22.TabIndex = 16;
            this.label22.Text = "Nome:";
            // 
            // tabPageEditarRestaurantes
            // 
            this.tabPageEditarRestaurantes.Controls.Add(this.textBoxTelemovelTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label13);
            this.tabPageEditarRestaurantes.Controls.Add(this.comboBoxEstadoTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label12);
            this.tabPageEditarRestaurantes.Controls.Add(this.textBoxCidadeTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label2);
            this.tabPageEditarRestaurantes.Controls.Add(this.textBoxPaisTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label4);
            this.tabPageEditarRestaurantes.Controls.Add(this.textBoxRuaTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label9);
            this.tabPageEditarRestaurantes.Controls.Add(this.textBoxCodPostalTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label10);
            this.tabPageEditarRestaurantes.Controls.Add(this.textBoxSalarioTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label5);
            this.tabPageEditarRestaurantes.Controls.Add(this.textBoxPosicaoTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label6);
            this.tabPageEditarRestaurantes.Controls.Add(this.textBoxNomeTrabalhadorAlterar);
            this.tabPageEditarRestaurantes.Controls.Add(this.label7);
            this.tabPageEditarRestaurantes.Controls.Add(this.buttonEditarTrabalhador);
            this.tabPageEditarRestaurantes.Location = new System.Drawing.Point(4, 22);
            this.tabPageEditarRestaurantes.Name = "tabPageEditarRestaurantes";
            this.tabPageEditarRestaurantes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEditarRestaurantes.Size = new System.Drawing.Size(323, 391);
            this.tabPageEditarRestaurantes.TabIndex = 1;
            this.tabPageEditarRestaurantes.Text = "Editar";
            this.tabPageEditarRestaurantes.UseVisualStyleBackColor = true;
            // 
            // textBoxTelemovelTrabalhadorAlterar
            // 
            this.textBoxTelemovelTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxTelemovelTrabalhadorAlterar.Location = new System.Drawing.Point(122, 70);
            this.textBoxTelemovelTrabalhadorAlterar.MaxLength = 9;
            this.textBoxTelemovelTrabalhadorAlterar.Name = "textBoxTelemovelTrabalhadorAlterar";
            this.textBoxTelemovelTrabalhadorAlterar.Size = new System.Drawing.Size(151, 26);
            this.textBoxTelemovelTrabalhadorAlterar.TabIndex = 47;
            this.textBoxTelemovelTrabalhadorAlterar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTelemovelTrabalhadorAlterar_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label13.Location = new System.Drawing.Point(30, 73);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 20);
            this.label13.TabIndex = 46;
            this.label13.Text = "Telemovel:";
            // 
            // comboBoxEstadoTrabalhadorAlterar
            // 
            this.comboBoxEstadoTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxEstadoTrabalhadorAlterar.FormattingEnabled = true;
            this.comboBoxEstadoTrabalhadorAlterar.Items.AddRange(new object[] {
            "Ativado",
            "Desativado"});
            this.comboBoxEstadoTrabalhadorAlterar.Location = new System.Drawing.Point(120, 304);
            this.comboBoxEstadoTrabalhadorAlterar.Name = "comboBoxEstadoTrabalhadorAlterar";
            this.comboBoxEstadoTrabalhadorAlterar.Size = new System.Drawing.Size(152, 28);
            this.comboBoxEstadoTrabalhadorAlterar.TabIndex = 45;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(50, 307);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 20);
            this.label12.TabIndex = 44;
            this.label12.Text = "Estado:";
            // 
            // textBoxCidadeTrabalhadorAlterar
            // 
            this.textBoxCidadeTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxCidadeTrabalhadorAlterar.Location = new System.Drawing.Point(122, 240);
            this.textBoxCidadeTrabalhadorAlterar.Name = "textBoxCidadeTrabalhadorAlterar";
            this.textBoxCidadeTrabalhadorAlterar.Size = new System.Drawing.Size(151, 26);
            this.textBoxCidadeTrabalhadorAlterar.TabIndex = 43;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(52, 243);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 20);
            this.label2.TabIndex = 42;
            this.label2.Text = "Cidade:";
            // 
            // textBoxPaisTrabalhadorAlterar
            // 
            this.textBoxPaisTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxPaisTrabalhadorAlterar.Location = new System.Drawing.Point(122, 272);
            this.textBoxPaisTrabalhadorAlterar.Name = "textBoxPaisTrabalhadorAlterar";
            this.textBoxPaisTrabalhadorAlterar.Size = new System.Drawing.Size(151, 26);
            this.textBoxPaisTrabalhadorAlterar.TabIndex = 41;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(72, 275);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 20);
            this.label4.TabIndex = 40;
            this.label4.Text = "Pais:";
            // 
            // textBoxRuaTrabalhadorAlterar
            // 
            this.textBoxRuaTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxRuaTrabalhadorAlterar.Location = new System.Drawing.Point(122, 171);
            this.textBoxRuaTrabalhadorAlterar.Name = "textBoxRuaTrabalhadorAlterar";
            this.textBoxRuaTrabalhadorAlterar.Size = new System.Drawing.Size(151, 26);
            this.textBoxRuaTrabalhadorAlterar.TabIndex = 39;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(72, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 20);
            this.label9.TabIndex = 38;
            this.label9.Text = "Rua:";
            // 
            // textBoxCodPostalTrabalhadorAlterar
            // 
            this.textBoxCodPostalTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxCodPostalTrabalhadorAlterar.Location = new System.Drawing.Point(122, 208);
            this.textBoxCodPostalTrabalhadorAlterar.MaxLength = 8;
            this.textBoxCodPostalTrabalhadorAlterar.Name = "textBoxCodPostalTrabalhadorAlterar";
            this.textBoxCodPostalTrabalhadorAlterar.Size = new System.Drawing.Size(151, 26);
            this.textBoxCodPostalTrabalhadorAlterar.TabIndex = 37;
            this.textBoxCodPostalTrabalhadorAlterar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCodPostalTrabalhadorAlterar_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label10.Location = new System.Drawing.Point(21, 211);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 20);
            this.label10.TabIndex = 36;
            this.label10.Text = "Cod. Postal:";
            // 
            // textBoxSalarioTrabalhadorAlterar
            // 
            this.textBoxSalarioTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxSalarioTrabalhadorAlterar.Location = new System.Drawing.Point(122, 139);
            this.textBoxSalarioTrabalhadorAlterar.Name = "textBoxSalarioTrabalhadorAlterar";
            this.textBoxSalarioTrabalhadorAlterar.Size = new System.Drawing.Size(151, 26);
            this.textBoxSalarioTrabalhadorAlterar.TabIndex = 35;
            this.textBoxSalarioTrabalhadorAlterar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSalarioTrabalhadorAlterar_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(54, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 20);
            this.label5.TabIndex = 34;
            this.label5.Text = "Salário:";
            // 
            // textBoxPosicaoTrabalhadorAlterar
            // 
            this.textBoxPosicaoTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxPosicaoTrabalhadorAlterar.Location = new System.Drawing.Point(122, 102);
            this.textBoxPosicaoTrabalhadorAlterar.Name = "textBoxPosicaoTrabalhadorAlterar";
            this.textBoxPosicaoTrabalhadorAlterar.Size = new System.Drawing.Size(151, 26);
            this.textBoxPosicaoTrabalhadorAlterar.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(47, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 20);
            this.label6.TabIndex = 32;
            this.label6.Text = "Posição:";
            // 
            // textBoxNomeTrabalhadorAlterar
            // 
            this.textBoxNomeTrabalhadorAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxNomeTrabalhadorAlterar.Location = new System.Drawing.Point(121, 38);
            this.textBoxNomeTrabalhadorAlterar.Name = "textBoxNomeTrabalhadorAlterar";
            this.textBoxNomeTrabalhadorAlterar.Size = new System.Drawing.Size(151, 26);
            this.textBoxNomeTrabalhadorAlterar.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(61, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 20);
            this.label7.TabIndex = 30;
            this.label7.Text = "Nome:";
            // 
            // buttonEditarTrabalhador
            // 
            this.buttonEditarTrabalhador.Location = new System.Drawing.Point(122, 350);
            this.buttonEditarTrabalhador.Name = "buttonEditarTrabalhador";
            this.buttonEditarTrabalhador.Size = new System.Drawing.Size(75, 23);
            this.buttonEditarTrabalhador.TabIndex = 29;
            this.buttonEditarTrabalhador.Text = "Editar";
            this.buttonEditarTrabalhador.UseVisualStyleBackColor = true;
            this.buttonEditarTrabalhador.Click += new System.EventHandler(this.buttonEditarTrabalhador_Click);
            // 
            // groupBoxListaTrabalhadores
            // 
            this.groupBoxListaTrabalhadores.Controls.Add(this.labelTotalSalarios);
            this.groupBoxListaTrabalhadores.Controls.Add(this.label);
            this.groupBoxListaTrabalhadores.Controls.Add(this.listBoxTrabalhadores);
            this.groupBoxListaTrabalhadores.Location = new System.Drawing.Point(6, 6);
            this.groupBoxListaTrabalhadores.Name = "groupBoxListaTrabalhadores";
            this.groupBoxListaTrabalhadores.Size = new System.Drawing.Size(363, 417);
            this.groupBoxListaTrabalhadores.TabIndex = 19;
            this.groupBoxListaTrabalhadores.TabStop = false;
            this.groupBoxListaTrabalhadores.Text = "Lista Trabalhadores";
            // 
            // labelTotalSalarios
            // 
            this.labelTotalSalarios.AutoSize = true;
            this.labelTotalSalarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalSalarios.Location = new System.Drawing.Point(89, 376);
            this.labelTotalSalarios.Name = "labelTotalSalarios";
            this.labelTotalSalarios.Size = new System.Drawing.Size(152, 25);
            this.labelTotalSalarios.TabIndex = 26;
            this.labelTotalSalarios.Text = "{TOTAL SAL}€";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(114, 339);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(101, 26);
            this.label.TabIndex = 25;
            this.label.Text = "TOTAL SALARIOS:\r\n(mensalmente)";
            // 
            // listBoxTrabalhadores
            // 
            this.listBoxTrabalhadores.FormattingEnabled = true;
            this.listBoxTrabalhadores.Location = new System.Drawing.Point(7, 20);
            this.listBoxTrabalhadores.Name = "listBoxTrabalhadores";
            this.listBoxTrabalhadores.Size = new System.Drawing.Size(350, 303);
            this.listBoxTrabalhadores.TabIndex = 0;
            this.listBoxTrabalhadores.SelectedIndexChanged += new System.EventHandler(this.listBoxTrabalhadores_SelectedIndexChanged);
            // 
            // tabPageMenus
            // 
            this.tabPageMenus.Controls.Add(this.buttonRemoverMenu);
            this.tabPageMenus.Controls.Add(this.groupBox2);
            this.tabPageMenus.Controls.Add(this.buttonAdicionarMenu);
            this.tabPageMenus.Controls.Add(this.groupBox1);
            this.tabPageMenus.Location = new System.Drawing.Point(4, 22);
            this.tabPageMenus.Name = "tabPageMenus";
            this.tabPageMenus.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMenus.Size = new System.Drawing.Size(719, 430);
            this.tabPageMenus.TabIndex = 1;
            this.tabPageMenus.Text = "Menus";
            this.tabPageMenus.UseVisualStyleBackColor = true;
            // 
            // buttonRemoverMenu
            // 
            this.buttonRemoverMenu.Location = new System.Drawing.Point(312, 191);
            this.buttonRemoverMenu.Name = "buttonRemoverMenu";
            this.buttonRemoverMenu.Size = new System.Drawing.Size(75, 23);
            this.buttonRemoverMenu.TabIndex = 4;
            this.buttonRemoverMenu.Text = "←Remover";
            this.buttonRemoverMenu.UseVisualStyleBackColor = true;
            this.buttonRemoverMenu.Click += new System.EventHandler(this.buttonRemoverMenu_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBoxMenuRestaurante);
            this.groupBox2.Location = new System.Drawing.Point(426, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(276, 421);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lista Menu do Restaurante";
            // 
            // listBoxMenuRestaurante
            // 
            this.listBoxMenuRestaurante.FormattingEnabled = true;
            this.listBoxMenuRestaurante.Location = new System.Drawing.Point(6, 23);
            this.listBoxMenuRestaurante.Name = "listBoxMenuRestaurante";
            this.listBoxMenuRestaurante.Size = new System.Drawing.Size(259, 381);
            this.listBoxMenuRestaurante.TabIndex = 1;
            // 
            // buttonAdicionarMenu
            // 
            this.buttonAdicionarMenu.Location = new System.Drawing.Point(312, 121);
            this.buttonAdicionarMenu.Name = "buttonAdicionarMenu";
            this.buttonAdicionarMenu.Size = new System.Drawing.Size(75, 23);
            this.buttonAdicionarMenu.TabIndex = 3;
            this.buttonAdicionarMenu.Text = "Adicionar→";
            this.buttonAdicionarMenu.UseVisualStyleBackColor = true;
            this.buttonAdicionarMenu.Click += new System.EventHandler(this.buttonAdicionarMenu_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxMenus);
            this.groupBox1.Location = new System.Drawing.Point(9, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(274, 418);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lista Menus";
            // 
            // listBoxMenus
            // 
            this.listBoxMenus.FormattingEnabled = true;
            this.listBoxMenus.Location = new System.Drawing.Point(6, 23);
            this.listBoxMenus.Name = "listBoxMenus";
            this.listBoxMenus.Size = new System.Drawing.Size(259, 381);
            this.listBoxMenus.TabIndex = 1;
            // 
            // FormIndividualRestaurante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 477);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormIndividualRestaurante";
            this.Text = "FormIndividualRestaurante";
            this.Load += new System.EventHandler(this.FormIndividualRestaurante_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPagePainelDeControlo.ResumeLayout(false);
            this.tabPagePainelDeControlo.PerformLayout();
            this.tabPageTrabalhadores.ResumeLayout(false);
            this.tabControlRestaurantes.ResumeLayout(false);
            this.tabPageInserirRestaurantes.ResumeLayout(false);
            this.tabPageInserirRestaurantes.PerformLayout();
            this.tabPageEditarRestaurantes.ResumeLayout(false);
            this.tabPageEditarRestaurantes.PerformLayout();
            this.groupBoxListaTrabalhadores.ResumeLayout(false);
            this.groupBoxListaTrabalhadores.PerformLayout();
            this.tabPageMenus.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPagePainelDeControlo;
        private System.Windows.Forms.TabPage tabPageTrabalhadores;
        private System.Windows.Forms.TabPage tabPageMenus;
        private System.Windows.Forms.TabControl tabControlRestaurantes;
        private System.Windows.Forms.TabPage tabPageInserirRestaurantes;
        private System.Windows.Forms.Button buttonAdicionarTrabalhador;
        private System.Windows.Forms.TextBox textBoxRuaTrabalhador;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxCodPostalTrabalhador;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxSalarioTrabalhador;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxPosicaoTrabalhador;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxNomeTrabalhador;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TabPage tabPageEditarRestaurantes;
        private System.Windows.Forms.TextBox textBoxSalarioTrabalhadorAlterar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxPosicaoTrabalhadorAlterar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxNomeTrabalhadorAlterar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonEditarTrabalhador;
        private System.Windows.Forms.GroupBox groupBoxListaTrabalhadores;
        private System.Windows.Forms.Label labelTotalSalarios;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.ListBox listBoxTrabalhadores;
        private System.Windows.Forms.ListBox listBoxMenus;
        private System.Windows.Forms.Label labelTotalFaturado;
        private System.Windows.Forms.Label labelNumeroPedidos;
        private System.Windows.Forms.Label labelNumeroTrabalhadores;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonRemoverMenu;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBoxMenuRestaurante;
        private System.Windows.Forms.Button buttonAdicionarMenu;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxRestaurantes;
        private System.Windows.Forms.TextBox textBoxCidadeTrabalhador;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxPaisTrabalhador;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxCidadeTrabalhadorAlterar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPaisTrabalhadorAlterar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxRuaTrabalhadorAlterar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxCodPostalTrabalhadorAlterar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBoxEstadoTrabalhador;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBoxEstadoTrabalhadorAlterar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxTelemovelTrabalhadorAlterar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxTelemovelTrabalhador;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button buttonPedidos;
    }
}